package StepDefinition;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utils.WebdriverWrapper;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MakeMyTrip {

	static Properties props = prop();
	static WebDriver driver = getBrowser(props.getProperty("browser"));
	private Scenario scenario;
	

	@Before
	public void beforeStep(Scenario scenario) {
		this.scenario = scenario;
		
		//scenario.getSourceTagNames();
		//scenario.write("Before Tag Executed");
	}

	@Given("^user logged into the application with valid scenario$")
	public void user_logged_into_the_application_with_valid_scenario() throws Throwable {

		driver.manage().window().maximize();
		driver.get(props.getProperty("url"));
		scenario.write("Application has been launched!");
		WebElement accountLoginButton = driver
				.findElement(By.xpath("//*[@class='makeFlex column flexOne']/descendant::input[@id='username']"));
		waitForElement(driver, accountLoginButton);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", accountLoginButton);

		waitForElement(driver, driver.findElement(By.id("username")));
		driver.findElement(By.id("username")).sendKeys(props.getProperty("username"));

		driver.findElement(By.xpath("//*[@data-cy='continueBtn']")).click();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		driver.findElement(By.id("password")).sendKeys(props.getProperty("password"));

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		fluentlyWait(driver, driver.findElement(By.xpath("//*[@class='btnContainer appendBottom25 ']//span")));
		driver.findElement(By.xpath("//*[@class='btnContainer appendBottom25 ']//span")).click();
		System.out.println("Performed login click");
		scenario.write("User Logged into the application successfully!");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		driver.navigate().refresh();

	}

	@When("^User Search trip from Pune to Ahmedabad for couple on (\\d+)th of August (\\d+) with Return date on (\\d+)th of August (\\d+) in Economy class$")
	public void user_Search_trip_from_Pune_to_Ahmedabad_for_couple_on_th_of_August_with_Return_date_on_th_of_August_in_Economy_class(
			int arg1, int arg2, int arg3, int arg4) throws Throwable {

		WebElement fromCity = driver.findElement(By.id("fromCity"));

		clickUsingAction(driver, fromCity);

		driver.findElement(By.xpath("//input[@type='text' and @placeholder='From']")).sendKeys("Ahmedabad, India");

		System.out.println(driver.findElement(By.xpath("//*[@role='listbox']/li[1]")).getText());

		java.util.List<WebElement> list = driver.findElements(By.xpath("//*[@role='listbox']/li"));
		for (WebElement webElement : list) {
			if (webElement.getText().contains("Ahmedabad")) {
				webElement.click();
				break;
			}

		}

		driver.navigate().refresh();
		WebElement toCity = driver.findElement(By.id("toCity"));
		clickUsingAction(driver, toCity);
		fluentlyWait(driver, driver.findElement(By.xpath("//input[@type='text' and @placeholder='To']")));
		
		for (int i = 0; i < 3; i++) {
			try {
				driver.findElement(By.xpath("//input[@type='text' and @placeholder='To']")).sendKeys("Pune, India");
				break;
			} catch (Exception e) {
				driver.navigate().refresh();
				fluentlyWait(driver, driver.findElement(By.xpath("//input[@type='text' and @placeholder='To']")));
				System.out.println(e.getMessage());

			}

		}
		// driver.findElement(By.xpath("//input[@type='text' and
		// @placeholder='To']")).sendKeys("Pune, India");
		java.util.List<WebElement> list2 = driver.findElements(By.xpath("//*[@role='listbox']/li"));
		for (WebElement webElement : list2) {
			if (webElement.getText().contains("Pune")) {
				webElement.click();
				break;
			}

		}

		// driver.findElement(By.xpath("//div[@class='makeFlex']/ul/li[2]")).click();

		driver.findElement(By.xpath("(//*[@class='lbl_input latoBold appendBottom10'])[1]")).click();
		driver.findElement(By.xpath("//*[@class='DayPicker-Day' and @aria-label='Sat Aug 28 2021']")).click();
		driver.navigate().refresh();
		driver.findElement(By.xpath("(//*[@class='lbl_input latoBold appendBottom10'])[2]")).click();
		driver.findElement(By.xpath("//*[@class='DayPicker-Day' and @aria-label='Fri Sep 03 2021']")).click();
		driver.navigate().refresh();
		driver.findElement(By.xpath("(//*[@class='lbl_input latoBold appendBottom10'])[3]")).click();
		driver.findElement(By.xpath("//*[@class='guestCounter font12 darkText gbCounter']/li[2]")).click();
		clickUsingAction(driver, driver.findElement(By.xpath("//*[@class='primaryBtn btnApply pushRight']")));
		scenario.write("User Entered Details for 2 Members in Economy- FromCity, ToCIty, Departure & Return Dates");
	}

	@When("^Modify Search of Return Date to (\\d+)th of August (\\d+) in Business class$")
	public void modify_Search_of_Return_Date_to_th_of_August_in_Business_class(int arg1, int arg2) throws Throwable {

		driver.navigate().refresh();
		driver.findElement(By.xpath("(//*[@class='lbl_input latoBold appendBottom10'])[3]")).click();
		driver.findElement(By.xpath("//*[@class='guestCounter font12 darkText gbCounter']/li[2]")).click();
		driver.findElement(By.xpath("//*[@class='guestCounter classSelect font12 darkText']/li[3]")).click();
		clickUsingAction(driver, driver.findElement(By.xpath("//*[@class='primaryBtn btnApply pushRight']")));

		driver.navigate().refresh();
		driver.findElement(By.xpath("(//*[@class='lbl_input latoBold appendBottom10'])[2]")).click();
		driver.findElement(
				By.xpath("//*[@class='DayPicker-Day DayPicker-Day--selected' and @aria-label='Wed Sep 01 2021']"))
				.click();
		scenario.write("User modified travel plan-Bussiness class and modified date");
		driver.navigate().refresh();
	}

	@When("^User Books flight with Minimum Price$")
	public void user_Books_flight_with_Minimum_Price() throws Throwable {

		clickUsingAction(driver,
				driver.findElement(By.xpath("//a[@class='primaryBtn font24 latoBold widgetSearchBtn ']")));
		fluentlyWait(driver, driver.findElement(By.xpath("//*[contains(text(),'Book')]")));
		clickUsingAction(driver, driver.findElement(By.xpath("//*[contains(text(),'Book')]")));
		scenario.write("User clicked on book button");
	}

	@Then("^Verify and Print GRAND TOTAL & Number of passengers under FARE SUMMARY$")
	public void verify_and_Print_GRAND_TOTAL_Number_of_passengers_under_FARE_SUMMARY() throws Throwable {

		String mainWindow = driver.getWindowHandle();

		System.out.println(mainWindow);

		clickUsingAction(driver, driver.findElement(By.xpath("//button[contains(text(),'Continue')]")));

		Set<String> windows = driver.getWindowHandles();
		for (String string : windows) {

			if (!string.equals(mainWindow)) {
				driver.switchTo().window(string);
				String grandTotal = driver.findElement(By.xpath("//*[@class='fareSummary']/div[@class='fareFooter']")).getText();
				scenario.write("Grand Total: " + grandTotal);

				driver.findElement(By.xpath("//*[@class='fareSummary']/div/div/div/span[@class='appendRight10 appendTop5']")).click();
				String passengerDetails = driver
						.findElement(By.xpath("//*[@class='fareSummary']/div[@class='fareTypeWrap']"))
						.getText();

				scenario.write("Total Passenger: " + passengerDetails);
				driver.close();
				driver.switchTo().window(mainWindow);

			}

			System.out.println(driver.getTitle());
		}

	}

	public static Properties prop() {
		Properties property = new Properties();
		FileInputStream fs;
		try {
			fs = new FileInputStream("config.propertise");
			property.load(fs);
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return property;

	}

	public static boolean waitForElement(WebDriver driver, WebElement ele) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(ele));
		return false;

	}

	public static boolean fluentlyWait(WebDriver driver, WebElement ele) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);

		WebElement foo = wait.until(ExpectedConditions.visibilityOf(ele));
		return true;
	}

	public void clickUsingJSExecutor(WebDriver driver, WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);
	}

	public void clickUsingAction(WebDriver driver, WebElement element) {
		Actions act = new Actions(driver);
		act.moveToElement(element).click().build().perform();
	}

	public static WebDriver getBrowser(String browser) {
		if (browser.equalsIgnoreCase("chrome")) {
			System.out.println("Path: " + System.getProperty("user.dir") + "\\drivers\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\drivers\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("start-maximized");
			options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
			options.setExperimentalOption("useAutomationExtension", false);
			driver = new ChromeDriver(options);

		} else if (browser.equalsIgnoreCase("Firefox")) {
			// can implement it later
		} else if (browser.equalsIgnoreCase("IE")) {
			// can implement it later
		}

		return driver;

	}
	

	@After
	public void AfterSteps(Scenario scenario) {
		
		driver.close();
		driver.quit();
		scenario.write("After tag executed");
	}
	
	@Given("^user launch the application$")
	public void userLanchestheApplication() {
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(props.getProperty("url"));
		scenario.write("Application has been launched!");
		
		
	}
	
	@When ("^user enters invalid user name and password$")
	public void userEntersWrongCredentials() {
		WebElement accountLoginButton = driver
				.findElement(By.xpath("//*[@class='makeFlex column flexOne']/descendant::input[@id='username']"));
		waitForElement(driver, accountLoginButton);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", accountLoginButton);

		waitForElement(driver, driver.findElement(By.id("username")));
		driver.findElement(By.id("username")).sendKeys(props.getProperty("username2"));

		driver.findElement(By.xpath("//*[@data-cy='continueBtn']")).click();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		driver.findElement(By.id("password")).sendKeys(props.getProperty("password2"));

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		fluentlyWait(driver, driver.findElement(By.xpath("//*[@class='btnContainer appendBottom25 ']//span")));
		driver.findElement(By.xpath("//*[@class='btnContainer appendBottom25 ']//span")).click();
	}
	
	@Then("^user should not be logged into the application$")
	public void validateAccountLogin() {
		
		WebElement loginButton=driver.findElement(By.xpath("//button[@data-cy='login']"));
		String errorMessage=driver.findElement(By.xpath("//*[@class='font12 redText appendTop5 makeFlex serverError hrtlCenter']")).getText();
		System.out.println(errorMessage);
		if(loginButton.isDisplayed()) {
			scenario.write("User Not Able To Login: "+errorMessage);
		}
		
	}

}
